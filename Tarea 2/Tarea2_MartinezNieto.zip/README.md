# Tarea 2

## Estudiantes
Daniel Alejandro Martínez Castro - 201973508-k  
Tomás Santiago Nieto Guerrero - 201973529-2

## Video

Link: [Link](https://drive.google.com/file/d/1TvnSFWYvZHcBQ5DsT0sk4UrWP_JoT0F4/view?usp=sharing)

## Requerimientos

python >= 3.10.6  
scikit-learn  
imblearn  
ipykernel  
dash  
pandas

## Instrucciones de ejecución

Abrir en Visual Studio Code los archivos clasificacion.ipynb y regresion.ipynb para visualizar el código.