# Tarea 1

## Estudiantes
Daniel Alejandro Martínez Castro - 201973508-k  
Tomás Santiago Nieto Guerrero - 201973529-2

## Video

Link: [Link](https://drive.google.com/file/d/1qefBOB1gu06nlEgwD94iPwENF4890eE0/view?usp=sharing)

## Requerimientos

python >= 3.10.6  
dash  
pandas

## Instrucciones de ejecución

Para ejecutar los Dashboards debe ejecutar en consola:

```bash
python app_p<n>.py
```

donde \<n\> es el número de la pregunta.
