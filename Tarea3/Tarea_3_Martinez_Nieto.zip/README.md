# Tarea 3 - Introducción a la ciencias de datos

Link: https://www.canva.com/design/DAGCJsYlzAI/nlUCQbIBufEjBtSK-0jrIA/watch?utm_content=DAGCJsYlzAI&utm_campaign=share_your_design&utm_medium=link&utm_source=shareyourdesignpanel

## Integrantes

Daniel Alejandro Martínez Castro  
Tomás Santiago Nieto Guerrero
